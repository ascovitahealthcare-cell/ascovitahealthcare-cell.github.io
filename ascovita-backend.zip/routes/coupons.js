'use strict';
const router = require('express').Router();
const { Op } = require('sequelize');
const { Coupon } = require('../models');
const { authenticate, requireAdmin, optionalAuth } = require('../middleware/auth');
const { audit } = require('../middleware/audit');

// ── PUBLIC: validate coupon ──────────────────────────────────────────────────
router.post('/validate', optionalAuth, async (req, res) => {
  try {
    const { code, orderTotal } = req.body;
    if (!code) return res.status(400).json({ error: 'Coupon code required' });

    const coupon = await Coupon.findOne({
      where: {
        code:      code.toUpperCase().trim(),
        is_active: true,
        [Op.or]: [{ starts_at: null }, { starts_at: { [Op.lte]: new Date() } }],
        [Op.or]: [{ expires_at: null }, { expires_at: { [Op.gte]: new Date() } }],
      },
    });

    if (!coupon) return res.status(404).json({ error: 'Invalid or expired coupon' });
    if (coupon.usage_limit && coupon.used_count >= coupon.usage_limit) {
      return res.status(400).json({ error: 'Coupon usage limit reached' });
    }
    if (orderTotal && parseFloat(orderTotal) < parseFloat(coupon.min_order_amt)) {
      return res.status(400).json({ error: `Minimum order ₹${coupon.min_order_amt} required` });
    }

    // Calculate discount
    let discountAmt = 0;
    if (coupon.type === 'flat') {
      discountAmt = parseFloat(coupon.value);
    } else if (coupon.type === 'percent') {
      discountAmt = (parseFloat(orderTotal) * parseFloat(coupon.value)) / 100;
      if (coupon.max_discount) discountAmt = Math.min(discountAmt, parseFloat(coupon.max_discount));
    } else if (coupon.type === 'free_shipping') {
      discountAmt = 0; // handled on frontend
    }

    res.json({
      valid:       true,
      coupon:      { id: coupon.id, code: coupon.code, type: coupon.type, value: coupon.value, description: coupon.description },
      discountAmt: Math.round(discountAmt * 100) / 100,
    });
  } catch (err) {
    res.status(500).json({ error: 'Coupon validation failed' });
  }
});

// ── ADMIN CRUD ─────────────────────────────────────────────────────────────
const adminRouter = require('express').Router();
adminRouter.use(authenticate, requireAdmin);

adminRouter.get('/', async (req, res) => {
  const coupons = await Coupon.findAll({ order: [['created_at','DESC']], paranoid: false });
  res.json({ data: coupons });
});

adminRouter.post('/', async (req, res) => {
  try {
    const c = await Coupon.create({ ...req.body, code: req.body.code?.toUpperCase() });
    await audit({ userId: req.user.id, tableName: 'coupons', recordId: c.id, action: 'INSERT', newValues: req.body });
    res.status(201).json({ data: c });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

adminRouter.put('/:id', async (req, res) => {
  try {
    const c = await Coupon.findByPk(req.params.id, { paranoid: false });
    if (!c) return res.status(404).json({ error: 'Not found' });
    if (c.deleted_at) await c.restore();
    await c.update(req.body);
    res.json({ data: c });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

adminRouter.delete('/:id', async (req, res) => {
  try {
    const c = await Coupon.findByPk(req.params.id);
    if (!c) return res.status(404).json({ error: 'Not found' });
    await c.destroy(); // soft-delete
    res.json({ message: 'Coupon soft-deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.use('/admin', adminRouter);
module.exports = router;
