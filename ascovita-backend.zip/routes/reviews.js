'use strict';
const router = require('express').Router();
const { Review, Product, Order, OrderItem } = require('../models');
const { optionalAuth, authenticate, requireAdmin } = require('../middleware/auth');

// ── Submit review ────────────────────────────────────────────────────────────
router.post('/', optionalAuth, async (req, res) => {
  try {
    const { productId, rating, title, body, reviewerName, orderId } = req.body;
    if (!productId || !rating) return res.status(400).json({ error: 'productId and rating required' });

    const product = await Product.findByPk(productId);
    if (!product) return res.status(404).json({ error: 'Product not found' });

    // Check purchase verification
    let isVerified = false;
    if (req.user && orderId) {
      const item = await OrderItem.findOne({ where: { order_id: orderId, product_id: productId } });
      isVerified = !!item;
    }

    const review = await Review.create({
      product_id:    productId,
      user_id:       req.user?.id || null,
      order_id:      orderId || null,
      rating,
      title:         title || null,
      body:          body  || null,
      reviewer_name: req.user?.name || reviewerName || 'Anonymous',
      is_verified:   isVerified,
      is_approved:   true,
    });
    res.status(201).json({ data: review });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ── Get reviews for product ──────────────────────────────────────────────────
router.get('/product/:productId', async (req, res) => {
  try {
    const reviews = await Review.findAll({
      where: { product_id: req.params.productId, is_approved: true },
      order: [['created_at','DESC']],
      attributes: ['id','rating','title','body','reviewer_name','is_verified','created_at'],
    });
    const avg = reviews.reduce((s, r) => s + r.rating, 0) / (reviews.length || 1);
    res.json({ data: reviews, avgRating: Math.round(avg * 10) / 10, count: reviews.length });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load reviews' });
  }
});

// ── ADMIN: manage reviews ────────────────────────────────────────────────────
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  const r = await Review.findByPk(req.params.id);
  if (!r) return res.status(404).json({ error: 'Not found' });
  await r.update(req.body);
  res.json({ data: r });
});
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  const r = await Review.findByPk(req.params.id);
  if (!r) return res.status(404).json({ error: 'Not found' });
  await r.destroy(); // soft-delete
  res.json({ message: 'Review soft-deleted' });
});

module.exports = router;
