'use strict';
const bcrypt = require('bcryptjs');

module.exports = {
  async up(queryInterface) {
    // Admin password comes from environment variable — never hardcoded
    const adminHash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'ChangeMe@123!', 12);
    const adminId   = '00000000-0000-0000-0000-000000000001';

    await queryInterface.bulkInsert('users', [{
      id:             adminId,
      role_id:        1,
      name:           'Ascovita Admin',
      email:          process.env.ADMIN_EMAIL || 'admin@ascovita.com',
      password_hash:  adminHash,
      provider:       'local',
      email_verified: true,
      is_active:      true,
      created_at:     new Date(),
      updated_at:     new Date(),
    }], { ignoreDuplicates: true });

    await queryInterface.bulkInsert('categories', [
      { name: 'Effervescent', slug: 'effervescent', is_active: true, sort_order: 1, created_at: new Date(), updated_at: new Date() },
      { name: 'Capsules',     slug: 'capsules',     is_active: true, sort_order: 2, created_at: new Date(), updated_at: new Date() },
      { name: 'Tablets',      slug: 'tablets',      is_active: true, sort_order: 3, created_at: new Date(), updated_at: new Date() },
    ], { ignoreDuplicates: true });

    await queryInterface.bulkInsert('coupons', [
      { code: 'TEST100', description: 'Demo 100% off coupon', type: 'percent', value: 100, min_order_amt: 0, is_active: true, created_at: new Date(), updated_at: new Date() },
      { code: 'FLAT50',  description: '₹50 flat discount',   type: 'flat',    value: 50,  min_order_amt: 199, is_active: true, created_at: new Date(), updated_at: new Date() },
    ], { ignoreDuplicates: true });

    console.log('✅ Seed complete');
  },

  async down(queryInterface) {
    await queryInterface.bulkDelete('coupons',    null, {});
    await queryInterface.bulkDelete('categories', null, {});
    await queryInterface.bulkDelete('users', { role_id: 1 }, {});
  },
};
