'use strict';
const jwt    = require('jsonwebtoken');
const crypto = require('crypto');
const { Session } = require('../models');

async function signToken(user, req) {
  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role_id },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );

  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const expiresAt = new Date(Date.now() + 7 * 864e5);

  await Session.create({
    user_id:    user.id,
    token_hash: tokenHash,
    ip_address: req?.ip || null,
    user_agent: req?.headers?.['user-agent'] || null,
    expires_at: expiresAt,
  });

  return token;
}

async function revokeToken(token) {
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  await Session.update({ revoked: true }, { where: { token_hash: hash } });
}

function userPayload(user) {
  return {
    id:       user.id,
    name:     user.name,
    email:    user.email,
    phone:    user.phone,
    picture:  user.avatar_url,
    role:     user.role_id,
    provider: user.provider,
  };
}

module.exports = { signToken, revokeToken, userPayload };
